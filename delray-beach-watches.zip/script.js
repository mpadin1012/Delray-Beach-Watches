const menuToggle = document.querySelector('.menu-toggle');
const siteNav = document.querySelector('.site-nav');

if (menuToggle && siteNav) {
  menuToggle.addEventListener('click', () => {
    siteNav.classList.toggle('open');
  });

  siteNav.querySelectorAll('a').forEach((link) => {
    link.addEventListener('click', () => siteNav.classList.remove('open'));
  });
}

const filterButtons = document.querySelectorAll('.filter-btn');
const watchCards = document.querySelectorAll('.watch-card');

filterButtons.forEach((button) => {
  button.addEventListener('click', () => {
    const selected = button.dataset.filter;

    filterButtons.forEach((btn) => btn.classList.remove('active'));
    button.classList.add('active');

    watchCards.forEach((card) => {
      const category = card.dataset.category;
      const show = selected === 'all' || selected === category;
      card.classList.toggle('hidden', !show);
    });
  });
});

const contactForm = document.getElementById('contactForm');
const contactFormMessage = document.getElementById('contactFormMessage');
const sellForm = document.getElementById('sellForm');
const sellFormMessage = document.getElementById('sellFormMessage');

function handleDemoForm(form, output, successText) {
  if (!form || !output) return;
  form.addEventListener('submit', (event) => {
    event.preventDefault();
    const data = new FormData(form);
    const name = data.get(form === sellForm ? 'name' : 'contactName') || 'there';
    output.textContent = `${successText} Thanks, ${name}.`;
    form.reset();
  });
}

handleDemoForm(contactForm, contactFormMessage, 'Your inquiry has been received.');
handleDemoForm(sellForm, sellFormMessage, 'Your watch details have been submitted.');

document.querySelectorAll('.link-btn').forEach((button) => {
  button.addEventListener('click', () => {
    const watch = button.dataset.watch;
    const messageBox = document.getElementById('message');
    const contactSection = document.getElementById('contact');
    if (messageBox) {
      messageBox.value = `Hi, I'm interested in the ${watch}. Please send me more details.`;
    }
    if (contactSection) {
      contactSection.scrollIntoView({ behavior: 'smooth' });
    }
  });
});
